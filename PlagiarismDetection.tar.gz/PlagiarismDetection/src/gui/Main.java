package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;

import bean.FileClass;
import util.ReadFiles;

public class Main{
	public static void main(String[] args) {
		FileClass file1 = new FileClass();
		JLabel result = new JLabel();
		JButton fromFileBtn = new JButton("Select File");
		//JButton toFileBtn = new JButton("Select File");
		JButton submit = new JButton("Check");
		JFrame.setDefaultLookAndFeelDecorated(true);
	    JDialog.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("Plagiarism Detection");
		fromFileBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.setMultiSelectionEnabled(true);
				file1.setFileChooser(chooser);
				int returnValue = file1.getFileChooser().showOpenDialog(null);
				if (returnValue == JFileChooser.APPROVE_OPTION) {
					file1.setSelectedFiles(chooser.getSelectedFiles());
					file1.setTotalFiles(file1.getSelectedFiles().length);
				}
			}
		});
		submit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				ReadFiles.readFile(file1);
				result.setText("Report is generated");
			}
		});
		frame.add(submit);
		frame.add(result);
		frame.add(fromFileBtn);
		//frame.add(toFileBtn);
		frame.setSize(500, 500);
		frame.setLayout(new FlowLayout());
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setVisible(true);
	}
}