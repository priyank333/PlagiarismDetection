package util;

import java.util.StringTokenizer;

import algorithms.MD5Hashing;
import bean.PlagiarismDetails;

public class CheckPlagiarism {
	public PlagiarismDetails validateData(String file1Data, String file2Data){
		PlagiarismDetails result = new PlagiarismDetails();
		String forDuplication;
		StringBuffer duplicateData = new StringBuffer();
		double duplicateCount=0, mismatched=0;
		StringTokenizer file1 = new StringTokenizer(file1Data);
		StringTokenizer file2 = new StringTokenizer(file2Data);
		while(file1.hasMoreTokens() && file2.hasMoreTokens()){
			if(MD5Hashing.getMD5((forDuplication=file1.nextToken())).equals(MD5Hashing.getMD5(file2.nextToken()))){
				duplicateCount++;
				duplicateData.append(forDuplication);
			}else{
				mismatched++;
			}
		}
		result.setPlagiarisedData(duplicateData);
		result.setPlagiarismPercentage((duplicateCount/(duplicateCount+mismatched))*100);
		return result;
	}
}
