package util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class WriteFile {
	public static void writeContent(StringBuffer content){
		try {
			String date=new Date().toString().replace(':', '-');
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File("report/report of "+date+".txt")));
			bufferedWriter.write(content.toString());
			bufferedWriter.flush();
			bufferedWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
