package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import bean.FileClass;
import bean.PlagiarismDetails;

public class ReadFiles {
	public static void readFile(FileClass file1){
		PlagiarismDetails result;
		Charset charset = Charset.forName("US-ASCII");
		StringBuffer toFileData = new StringBuffer();
		StringBuffer fromFileData = new StringBuffer();
		StringBuffer writeDataContent = new StringBuffer();
		writeDataContent.append("\t\t\t\tPlagiarism Report\n\n-----------------------------------------------------------------------------\n\n");
		for(int i=0;i<file1.getTotalFiles()-1;i++){
			Path fromPath = Paths.get(file1.getSelectedFiles()[i].getPath());
			writeDataContent.append((i+1) + ") Details about source file:\n\n");
			writeDataContent.append("File Name: " + fromPath.getFileName().toString()+"\n");
			writeDataContent.append("File Location: " + fromPath.toUri()+"\n");
			writeDataContent.append("File Size: " + file1.getSelectedFiles()[i].length()+" Bytes\n\n");
			try(BufferedReader bufferedReader = Files.newBufferedReader(fromPath,charset)){
				fromFileData= new StringBuffer();
				String line=null;
				while((line=bufferedReader.readLine())!=null){
					fromFileData.append(line);
				}
			}
			catch(IOException exception){
				
			}
			for(int j=(i+1);j<file1.getTotalFiles();j++){
				Path toPath = Paths.get(file1.getSelectedFiles()[j].getPath());
				writeDataContent.append("Details about a file whereby file is matched: \n\n");
				writeDataContent.append(fromPath.getFileName() + " is matched with " + toPath.getFileName() + "\n\n");
				writeDataContent.append("File Name: " + toPath.getFileName().toString()+"\n");
				writeDataContent.append("File Location: " + toPath.toUri()+"\n");
				writeDataContent.append("File Size: " + file1.getSelectedFiles()[j].length()+" Bytes\n\n");
				try(BufferedReader bufferedReader = Files.newBufferedReader(toPath,charset)){
					String line=null;
					while((line=bufferedReader.readLine())!=null){
						toFileData.append(line);
					}
				}
				catch(IOException exception){
					
				}
				result = new CheckPlagiarism().validateData(new String(fromFileData).toLowerCase(),new String(toFileData).toLowerCase());
				writeDataContent.append("Is there any duplication in a data: ");
				if(result.getPlagiarismPercentage()!=0.00){
					writeDataContent.append("Yes\n");
					writeDataContent.append("Duplicate Content : \n");
					writeDataContent.append(result.getPlagiarisedData());
					writeDataContent.append("\n\nPercentage : ");
					writeDataContent.append(result.getPlagiarismPercentage()+"%");
					writeDataContent.append("\n\n");
				}else{
					writeDataContent.append("No\n");
				}
				writeDataContent.append("---------------------------------------------------\n\n");
			}
			writeDataContent.append("---------------------------------------------------------------------\n\n");
		}
		WriteFile.writeContent(writeDataContent);
	}
}
