package bean;

public class PlagiarismDetails {
	private StringBuffer plagiarisedData;
	private double plagiarismPercentage;
	public StringBuffer getPlagiarisedData() {
		return plagiarisedData;
	}
	public void setPlagiarisedData(StringBuffer plagiarisedData) {
		this.plagiarisedData = plagiarisedData;
	}
	public double getPlagiarismPercentage() {
		return plagiarismPercentage;
	}
	public void setPlagiarismPercentage(double plagiarismPercentage) {
		this.plagiarismPercentage = plagiarismPercentage;
	}
	
}
