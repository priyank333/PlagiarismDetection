package bean;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.JFileChooser;

public class FileClass {
	private JFileChooser fileChooser;
	private InputStream reader;
	private InputStreamReader inputStreamReader;
  	private BufferedReader bufferedReader;
	private File selectedFiles[];
	private int totalFiles;
	public File[] getSelectedFiles() {
		return selectedFiles;
	}
	public void setSelectedFiles(File[] selectedFiles) {
		this.selectedFiles = selectedFiles;
	}
	public int getTotalFiles() {
		return totalFiles;
	}
	public void setTotalFiles(int totalFiles) {
		this.totalFiles = totalFiles;
	}
	public JFileChooser getFileChooser() {
		return fileChooser;
	}
	public void setFileChooser(JFileChooser fileChooser) {
		this.fileChooser = fileChooser;
	}
	public InputStream getReader() {
		return reader;
	}
	public void setReader(InputStream reader) {
		this.reader = reader;
	}
	public InputStreamReader getInputStreamReader() {
		return inputStreamReader;
	}
	public void setInputStreamReader(InputStreamReader inputStreamReader) {
		this.inputStreamReader = inputStreamReader;
	}
	public BufferedReader getBufferedReader() {
		return bufferedReader;
	}
	public void setBufferedReader(BufferedReader bufferedReader) {
		this.bufferedReader = bufferedReader;
	}
}
